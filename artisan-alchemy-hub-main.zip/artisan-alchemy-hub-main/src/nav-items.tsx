import { HomeIcon, UserIcon, ShieldIcon, type LucideIcon } from "lucide-react";

import Index from "./pages/Index.tsx";
import Auth from "./pages/Auth.tsx";
import Dashboard from "./pages/Dashboard.tsx";
import NotFound from "./pages/NotFound.tsx";

export interface NavItem {
  title: string;
  to: string;
  icon: LucideIcon;
  page: React.ComponentType;
}

const navItems: NavItem[] = [
  {
    title: "Home",
    to: "/",
    icon: HomeIcon,
    page: Index,
  },
  {
    title: "Authentication",
    to: "/auth",
    icon: UserIcon,
    page: Auth,
  },
  {
    title: "Dashboard",
    to: "/dashboard",
    icon: ShieldIcon,
    page: Dashboard,
  },
  {
    title: "Not Found",
    to: "*",
    icon: HomeIcon,
    page: NotFound,
  },
];

export { navItems };