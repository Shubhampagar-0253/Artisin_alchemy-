import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://yqerwkzqnofxfcaltehw.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlxZXJ3a3pxbm9meGZjYWx0ZWh3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzY1Mzg5NjEsImV4cCI6MjA1MjExNDk2MX0.Gi_dOhhPLXg2qvchIHNGfYGrEfP42FdQhGC7Mq0CxZE';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type UserRole = 'customer' | 'artist' | 'admin';

export interface UserProfile {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  role: UserRole;
  phone?: string;
  verification_status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  updated_at: string;
}

export interface ArtistProfile {
  id: string;
  business_name: string;
  bio?: string;
  specialties: string[];
  location?: string;
  portfolio_images: string[];
  verification_documents: string[];
  rating: number;
  total_sales: number;
  follower_count: number;
  verification_status: 'pending' | 'approved' | 'rejected';
  verification_date?: string;
  verified_by?: string;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  artist_id: string;
  title: string;
  description: string;
  price: number;
  stock_quantity: number;
  category: string;
  materials: string[];
  dimensions?: string;
  weight?: number;
  is_active: boolean;
  authenticity_status: 'pending_review' | 'verified' | 'suspicious';
  authenticity_score?: number;
  created_at: string;
  updated_at: string;
  artist_profiles?: ArtistProfile;
  product_images?: { image_url: string }[];
  product_stories?: ProductStory[];
}

export interface ProductStory {
  id: string;
  product_id: string;
  story_text: string;
  story_type: 'artist_written' | 'ai_generated';
  inspiration?: string;
  creation_process?: string;
  cultural_significance?: string;
  generated_keywords?: string[];
  is_published: boolean;
  created_at: string;
  updated_at: string;
}

export interface CartItem {
  id: string;
  user_id: string;
  product_id: string;
  quantity: number;
  created_at: string;
  products?: Product;
}

export interface Order {
  id: string;
  order_number: string;
  customer_id: string;
  subtotal: number;
  tax_amount: number;
  shipping_amount: number;
  discount_amount: number;
  total_amount: number;
  currency: string;
  status: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  payment_status: 'pending' | 'completed' | 'failed' | 'refunded';
  payment_intent_id?: string;
  shipping_address: any;
  billing_address: any;
  created_at: string;
  updated_at: string;
}