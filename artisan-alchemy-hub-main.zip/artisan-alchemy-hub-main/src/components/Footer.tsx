import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Heart, Mail, Facebook, Instagram, Twitter, Youtube, MapPin, Phone, Clock } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-accent text-accent-foreground">
      {/* Newsletter Section */}
      <div className="border-b border-accent-foreground/10">
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <Badge variant="secondary" className="bg-artisan-warm text-accent font-medium">
              <Mail className="h-3 w-3 mr-1" />
              Stay Connected
            </Badge>
            <h3 className="text-3xl font-bold">
              Get Inspired by Artisan Stories
            </h3>
            <p className="text-accent-foreground/80 max-w-2xl mx-auto">
              Subscribe to our newsletter and discover new artists, exclusive collections, 
              and the fascinating stories behind handcrafted treasures.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <Input 
                placeholder="Enter your email address" 
                className="bg-accent-foreground/10 border-accent-foreground/20 text-accent-foreground placeholder:text-accent-foreground/60"
              />
              <Button variant="secondary" className="bg-primary text-primary-foreground hover:bg-primary/90">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand & Mission */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h2 className="text-2xl font-bold bg-gradient-hero bg-clip-text text-transparent mb-3">
                Artisan Alchemy
              </h2>
              <p className="text-accent-foreground/80 leading-relaxed">
                We're more than a marketplace—we're a community that celebrates the art of handcrafting. 
                Every purchase supports independent artisans and preserves traditional craftsmanship for future generations.
              </p>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-accent-foreground">Our Mission</h4>
              <div className="flex items-start gap-3">
                <Heart className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                <p className="text-sm text-accent-foreground/80">
                  Connecting authentic artisans with conscious consumers who value quality, 
                  sustainability, and the human story behind every handcrafted piece.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h4 className="font-semibold text-accent-foreground">Quick Links</h4>
            <div className="grid grid-cols-2 lg:grid-cols-1 gap-3">
              <a href="#" className="text-sm text-accent-foreground/80 hover:text-accent-foreground transition-smooth">
                Browse Products
              </a>
              <a href="#" className="text-sm text-accent-foreground/80 hover:text-accent-foreground transition-smooth">
                Featured Artists
              </a>
              <a href="#" className="text-sm text-accent-foreground/80 hover:text-accent-foreground transition-smooth">
                New Arrivals
              </a>
              <a href="#" className="text-sm text-accent-foreground/80 hover:text-accent-foreground transition-smooth">
                Best Sellers
              </a>
              <a href="#" className="text-sm text-accent-foreground/80 hover:text-accent-foreground transition-smooth">
                Gift Collections
              </a>
              <a href="#" className="text-sm text-accent-foreground/80 hover:text-accent-foreground transition-smooth">
                Artisan Stories
              </a>
            </div>
          </div>

          {/* Support & Contact */}
          <div className="space-y-6">
            <h4 className="font-semibold text-accent-foreground">Support & Contact</h4>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <MapPin className="h-4 w-4 text-primary flex-shrink-0" />
                <span className="text-sm text-accent-foreground/80">
                  San Francisco, CA
                </span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-primary flex-shrink-0" />
                <span className="text-sm text-accent-foreground/80">
                  +1 (555) 123-4567
                </span>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="h-4 w-4 text-primary flex-shrink-0" />
                <span className="text-sm text-accent-foreground/80">
                  Mon-Fri: 9AM-6PM PST
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <h5 className="font-medium text-accent-foreground">Follow Us</h5>
              <div className="flex gap-3">
                <Button variant="ghost" size="icon" className="text-accent-foreground/60 hover:text-accent-foreground hover:bg-accent-foreground/10">
                  <Facebook className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="text-accent-foreground/60 hover:text-accent-foreground hover:bg-accent-foreground/10">
                  <Instagram className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="text-accent-foreground/60 hover:text-accent-foreground hover:bg-accent-foreground/10">
                  <Twitter className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="text-accent-foreground/60 hover:text-accent-foreground hover:bg-accent-foreground/10">
                  <Youtube className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-accent-foreground/10">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-sm text-accent-foreground/60">
              © 2024 Artisan Alchemy. Made with love for authentic craftsmanship.
            </p>
            <div className="flex gap-6 text-sm text-accent-foreground/60">
              <a href="#" className="hover:text-accent-foreground transition-smooth">Privacy Policy</a>
              <a href="#" className="hover:text-accent-foreground transition-smooth">Terms of Service</a>
              <a href="#" className="hover:text-accent-foreground transition-smooth">Return Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;