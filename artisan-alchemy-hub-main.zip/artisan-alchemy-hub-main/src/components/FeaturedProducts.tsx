import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import ProductCard from "./ProductCard";
import { ArrowRight, Sparkles } from "lucide-react";
import potteryImage from "@/assets/pottery-collection.jpg";

const FeaturedProducts = () => {
  // Sample product data
  const featuredProducts = [
    {
      id: "1",
      title: "Handcrafted Ceramic Bowl Set",
      artist: "Maria Santos",
      price: 89,
      originalPrice: 120,
      image: potteryImage,
      rating: 4.9,
      reviewCount: 47,
      category: "Pottery & Ceramics",
      isFeatured: true,
      isHandcrafted: true
    },
    {
      id: "2", 
      title: "Rustic Wooden Serving Tray",
      artist: "James Cooper",
      price: 65,
      image: potteryImage,
      rating: 4.8,
      reviewCount: 32,
      category: "Wood & Furniture",
      isFeatured: true,
      isHandcrafted: true
    },
    {
      id: "3",
      title: "Hand-woven Textile Wall Art",
      artist: "Priya Sharma",
      price: 145,
      originalPrice: 180,
      image: potteryImage,
      rating: 5.0,
      reviewCount: 23,
      category: "Textiles & Fiber",
      isFeatured: true,
      isHandcrafted: true
    },
    {
      id: "4",
      title: "Artisan Silver Jewelry Set",
      artist: "Carlos Rodriguez",
      price: 199,
      image: potteryImage,
      rating: 4.7,
      reviewCount: 91,
      category: "Jewelry & Accessories",
      isFeatured: true,
      isHandcrafted: true
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="flex items-center justify-between mb-12">
          <div className="space-y-4">
            <Badge variant="secondary" className="bg-artisan-warm text-accent font-medium">
              <Sparkles className="h-3 w-3 mr-1" />
              Featured Collections
            </Badge>
            <h2 className="text-4xl font-bold text-foreground">
              Discover Handcrafted
              <span className="block text-primary">Masterpieces</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl">
              Each piece in our featured collection represents hours of dedication, 
              traditional techniques, and the unique vision of talented artisans from around the world.
            </p>
          </div>
          
          <Button variant="outline" size="lg" className="hidden md:flex">
            View All Products
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} {...product} />
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <Button variant="hero" size="xl" className="shadow-warm">
            Explore All Collections
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;