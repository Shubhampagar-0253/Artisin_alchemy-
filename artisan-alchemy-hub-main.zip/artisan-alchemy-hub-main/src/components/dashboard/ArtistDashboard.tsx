import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { UserProfile, Product, ArtistProfile, supabase } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Package, DollarSign, Star, TrendingUp, Edit, Trash2, Eye, Sparkles, Shield } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

interface ArtistDashboardProps {
  profile: UserProfile;
}

const ArtistDashboard: React.FC<ArtistDashboardProps> = ({ profile }) => {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const [artistProfile, setArtistProfile] = useState<ArtistProfile | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [newProduct, setNewProduct] = useState({
    title: '',
    description: '',
    price: '',
    stock_quantity: '',
    category: '',
    materials: '',
    dimensions: '',
    weight: ''
  });

  useEffect(() => {
    fetchArtistData();
  }, []);

  const fetchArtistData = async () => {
    try {
      // Fetch artist profile
      const { data: artistData } = await supabase
        .from('artist_profiles')
        .select('*')
        .eq('id', profile.id)
        .single();

      // Fetch products
      const { data: productsData } = await supabase
        .from('products')
        .select(`
          *,
          product_images (image_url),
          product_stories (*)
        `)
        .eq('artist_id', profile.id)
        .order('created_at', { ascending: false });

      // Fetch orders for this artist's products
      const { data: ordersData } = await supabase
        .from('order_items')
        .select(`
          *,
          orders (
            id, order_number, status, payment_status, total_amount, created_at,
            user_profiles (first_name, last_name, email)
          ),
          products (title, price)
        `)
        .eq('artist_id', profile.id)
        .order('created_at', { ascending: false });

      setArtistProfile(artistData);
      setProducts(productsData || []);
      setOrders(ordersData || []);
    } catch (error) {
      console.error('Error fetching artist data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const createProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newProduct.title || !newProduct.description || !newProduct.price || !newProduct.category) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('products')
        .insert({
          artist_id: profile.id,
          title: newProduct.title,
          description: newProduct.description,
          price: parseFloat(newProduct.price),
          stock_quantity: parseInt(newProduct.stock_quantity) || 1,
          category: newProduct.category,
          materials: newProduct.materials.split(',').map(m => m.trim()),
          dimensions: newProduct.dimensions || null,
          weight: newProduct.weight ? parseFloat(newProduct.weight) : null,
          is_active: true,
          authenticity_status: 'pending_review'
        })
        .select()
        .single();

      if (error) throw error;

      setProducts(prev => [data, ...prev]);
      setNewProduct({
        title: '',
        description: '',
        price: '',
        stock_quantity: '',
        category: '',
        materials: '',
        dimensions: '',
        weight: ''
      });
      
      toast.success('Product created successfully! It will be reviewed before going live.');
    } catch (error) {
      console.error('Error creating product:', error);
      toast.error('Failed to create product');
    }
  };

  const generateStory = async (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    try {
      const { data, error } = await supabase.functions.invoke('ai-story-generator', {
        body: {
          productId: product.id,
          productTitle: product.title,
          productDescription: product.description,
          materials: product.materials,
          artistName: artistProfile?.business_name || profile.first_name,
          category: product.category
        }
      });

      if (error) throw error;

      if (data.success) {
        toast.success(data.message);
        fetchArtistData(); // Refresh to show the new story
      } else {
        toast.error(data.error);
      }
    } catch (error) {
      console.error('Error generating story:', error);
      toast.error('Failed to generate story');
    }
  };

  const checkAuthenticity = async (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (!product || !product.product_images?.[0]) {
      toast.error('Product needs an image for authenticity check');
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('image-authenticity-check', {
        body: {
          productId: product.id,
          imageUrl: product.product_images[0].image_url,
          category: product.category
        }
      });

      if (error) throw error;

      if (data.success) {
        toast.success(data.result.message);
        fetchArtistData(); // Refresh to show updated authenticity status
      } else {
        toast.error(data.error);
      }
    } catch (error) {
      console.error('Error checking authenticity:', error);
      toast.error('Failed to check authenticity');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Calculate stats
  const totalProducts = products.length;
  const activeProducts = products.filter(p => p.is_active).length;
  const totalRevenue = orders.reduce((sum, order) => sum + (order.total_price || 0), 0);
  const avgRating = artistProfile?.rating || 0;

  const getAuthenticityBadge = (status: string, score?: number) => {
    switch (status) {
      case 'verified':
        return <Badge className="bg-green-500 text-white">✓ Verified</Badge>;
      case 'suspicious':
        return <Badge className="bg-red-500 text-white">⚠ Flagged</Badge>;
      case 'pending_review':
        return <Badge className="bg-yellow-500 text-white">⏳ Pending</Badge>;
      default:
        return <Badge variant="outline">Not Checked</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Artist Dashboard</h1>
            <p className="text-muted-foreground">
              Welcome back, {artistProfile?.business_name || profile.first_name}
            </p>
            {profile.verification_status === 'pending' && (
              <Badge className="mt-2 bg-yellow-500 text-white">
                Account Pending Verification
              </Badge>
            )}
            {profile.verification_status === 'approved' && (
              <Badge className="mt-2 bg-green-500 text-white">
                ✓ Verified Artist
              </Badge>
            )}
          </div>
          <div className="flex gap-4">
            <Button variant="outline" onClick={() => navigate('/')}>
              View Storefront
            </Button>
            <Button variant="outline" onClick={signOut}>
              Sign Out
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Package className="h-8 w-8 text-primary mr-3" />
                <div>
                  <p className="text-2xl font-bold">{totalProducts}</p>
                  <p className="text-sm text-muted-foreground">Total Products</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <TrendingUp className="h-8 w-8 text-green-500 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{activeProducts}</p>
                  <p className="text-sm text-muted-foreground">Active Products</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-green-600 mr-3" />
                <div>
                  <p className="text-2xl font-bold">${totalRevenue.toFixed(2)}</p>
                  <p className="text-sm text-muted-foreground">Total Revenue</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Star className="h-8 w-8 text-yellow-500 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{avgRating.toFixed(1)}</p>
                  <p className="text-sm text-muted-foreground">Average Rating</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="products" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="add-product">Add Product</TabsTrigger>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="products" className="space-y-4">
            {products.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">No products yet</h3>
                  <p className="text-muted-foreground mb-4">Create your first handcrafted product</p>
                  <Button onClick={() => navigate('/dashboard?tab=add-product')}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Product
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product) => (
                  <Card key={product.id}>
                    <CardContent className="p-4">
                      <img
                        src={product.product_images?.[0]?.image_url || '/placeholder.svg'}
                        alt={product.title}
                        className="w-full h-48 object-cover rounded-lg mb-4"
                      />
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold flex-1">{product.title}</h3>
                        {getAuthenticityBadge(product.authenticity_status, product.authenticity_score)}
                      </div>
                      <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                        {product.description}
                      </p>
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-lg font-bold">${product.price.toFixed(2)}</span>
                        <span className="text-sm text-muted-foreground">
                          Stock: {product.stock_quantity}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => generateStory(product.id)}
                        >
                          <Sparkles className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => checkAuthenticity(product.id)}
                        >
                          <Shield className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="add-product">
            <Card>
              <CardHeader>
                <CardTitle>Add New Product</CardTitle>
                <CardDescription>Create a new handcrafted product listing</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={createProduct} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="title">Product Title *</Label>
                      <Input
                        id="title"
                        value={newProduct.title}
                        onChange={(e) => setNewProduct({ ...newProduct, title: e.target.value })}
                        placeholder="Beautiful handcrafted vase"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="category">Category *</Label>
                      <Select value={newProduct.category} onValueChange={(value) => setNewProduct({ ...newProduct, category: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pottery">Pottery & Ceramics</SelectItem>
                          <SelectItem value="textiles">Textiles & Fiber</SelectItem>
                          <SelectItem value="wood">Wood & Furniture</SelectItem>
                          <SelectItem value="jewelry">Jewelry & Accessories</SelectItem>
                          <SelectItem value="art">Art & Paintings</SelectItem>
                          <SelectItem value="metal">Metalwork</SelectItem>
                          <SelectItem value="glass">Glasswork</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description *</Label>
                    <Textarea
                      id="description"
                      value={newProduct.description}
                      onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                      placeholder="Describe your handcrafted product, its inspiration, and unique features..."
                      rows={4}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="price">Price (USD) *</Label>
                      <Input
                        id="price"
                        type="number"
                        step="0.01"
                        value={newProduct.price}
                        onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                        placeholder="29.99"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="stock">Stock Quantity</Label>
                      <Input
                        id="stock"
                        type="number"
                        value={newProduct.stock_quantity}
                        onChange={(e) => setNewProduct({ ...newProduct, stock_quantity: e.target.value })}
                        placeholder="1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="weight">Weight (lbs)</Label>
                      <Input
                        id="weight"
                        type="number"
                        step="0.1"
                        value={newProduct.weight}
                        onChange={(e) => setNewProduct({ ...newProduct, weight: e.target.value })}
                        placeholder="2.5"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="materials">Materials (comma-separated)</Label>
                      <Input
                        id="materials"
                        value={newProduct.materials}
                        onChange={(e) => setNewProduct({ ...newProduct, materials: e.target.value })}
                        placeholder="clay, glaze, natural pigments"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dimensions">Dimensions</Label>
                      <Input
                        id="dimensions"
                        value={newProduct.dimensions}
                        onChange={(e) => setNewProduct({ ...newProduct, dimensions: e.target.value })}
                        placeholder="10&quot; H x 6&quot; W x 6&quot; D"
                      />
                    </div>
                  </div>

                  <Button type="submit" className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Create Product
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="orders" className="space-y-4">
            {orders.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">No orders yet</h3>
                  <p className="text-muted-foreground">Orders for your products will appear here</p>
                </CardContent>
              </Card>
            ) : (
              orders.map((orderItem) => (
                <Card key={orderItem.id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold">
                          Order #{orderItem.orders?.order_number}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {orderItem.products?.title} × {orderItem.quantity}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Customer: {orderItem.orders?.user_profiles?.first_name} {orderItem.orders?.user_profiles?.last_name}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">${orderItem.total_price?.toFixed(2)}</p>
                        <Badge className={orderItem.orders?.status === 'delivered' ? 'bg-green-500' : 'bg-yellow-500'}>
                          {orderItem.orders?.status}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Artist Profile</CardTitle>
                <CardDescription>Manage your artist information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Business Name</label>
                    <p className="text-muted-foreground">
                      {artistProfile?.business_name || 'Not set'}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Verification Status</label>
                    <p className="text-muted-foreground">{profile.verification_status}</p>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium">Bio</label>
                  <p className="text-muted-foreground">
                    {artistProfile?.bio || 'No bio provided'}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium">Specialties</label>
                  <p className="text-muted-foreground">
                    {artistProfile?.specialties?.join(', ') || 'No specialties listed'}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium">Location</label>
                  <p className="text-muted-foreground">
                    {artistProfile?.location || 'Location not specified'}
                  </p>
                </div>
                <Button variant="outline">Edit Profile</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ArtistDashboard;