import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Package, DollarSign, AlertTriangle, CheckCircle, XCircle, Eye, Shield } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

interface AdminStats {
  users: {
    total: number;
    artists: number;
    pendingArtists: number;
    customers: number;
  };
  products: {
    total: number;
    pendingReview: number;
  };
  orders: {
    total: number;
    recent: any[];
  };
  revenue: {
    monthly: number;
    currency: string;
  };
  topArtists: any[];
  securityAlerts: any[];
}

const AdminDashboard = () => {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [pendingReviews, setPendingReviews] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAdminData();
  }, []);

  const fetchAdminData = async () => {
    try {
      // Fetch dashboard stats
      const { data: statsData, error: statsError } = await supabase.functions.invoke('admin-dashboard', {
        body: { action: 'get_stats' }
      });

      if (statsError) throw statsError;

      // Fetch pending reviews
      const { data: reviewsData, error: reviewsError } = await supabase.functions.invoke('admin-dashboard', {
        body: { action: 'get_pending_reviews' }
      });

      if (reviewsError) throw reviewsError;

      setStats(statsData.stats);
      setPendingReviews(reviewsData.pending);
    } catch (error) {
      console.error('Error fetching admin data:', error);
      toast.error('Failed to load admin dashboard');
    } finally {
      setLoading(false);
    }
  };

  const approveArtist = async (userId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('admin-dashboard', {
        body: {
          action: 'approve_artist',
          userId
        }
      });

      if (error) throw error;

      if (data.success) {
        toast.success(data.message);
        fetchAdminData(); // Refresh data
      } else {
        toast.error(data.error);
      }
    } catch (error) {
      console.error('Error approving artist:', error);
      toast.error('Failed to approve artist');
    }
  };

  const rejectArtist = async (userId: string, reason?: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('admin-dashboard', {
        body: {
          action: 'reject_artist',
          userId,
          reason
        }
      });

      if (error) throw error;

      if (data.success) {
        toast.success(data.message);
        fetchAdminData(); // Refresh data
      } else {
        toast.error(data.error);
      }
    } catch (error) {
      console.error('Error rejecting artist:', error);
      toast.error('Failed to reject artist');
    }
  };

  const approveProduct = async (productId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('admin-dashboard', {
        body: {
          action: 'approve_product',
          productId
        }
      });

      if (error) throw error;

      if (data.success) {
        toast.success(data.message);
        fetchAdminData(); // Refresh data
      } else {
        toast.error(data.error);
      }
    } catch (error) {
      console.error('Error approving product:', error);
      toast.error('Failed to approve product');
    }
  };

  const rejectProduct = async (productId: string, reason?: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('admin-dashboard', {
        body: {
          action: 'reject_product',
          productId,
          reason
        }
      });

      if (error) throw error;

      if (data.success) {
        toast.success(data.message);
        fetchAdminData(); // Refresh data
      } else {
        toast.error(data.error);
      }
    } catch (error) {
      console.error('Error rejecting product:', error);
      toast.error('Failed to reject product');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md text-center">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-2">Error Loading Dashboard</h3>
            <p className="text-muted-foreground mb-4">Failed to load admin dashboard data</p>
            <Button onClick={fetchAdminData}>Retry</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage platform operations and security</p>
          </div>
          <div className="flex gap-4">
            <Button variant="outline" onClick={() => navigate('/')}>
              View Platform
            </Button>
            <Button variant="outline" onClick={signOut}>
              Sign Out
            </Button>
          </div>
        </div>

        {/* Security Alerts */}
        {stats.securityAlerts.length > 0 && (
          <Card className="mb-8 border-red-200 bg-red-50">
            <CardHeader>
              <CardTitle className="flex items-center text-red-700">
                <AlertTriangle className="h-5 w-5 mr-2" />
                Security Alerts ({stats.securityAlerts.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {stats.securityAlerts.slice(0, 3).map((alert) => (
                  <div key={alert.id} className="flex items-center justify-between p-2 bg-white rounded">
                    <div>
                      <p className="font-medium">{alert.description}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(alert.created_at).toLocaleString()}
                      </p>
                    </div>
                    <Badge className={alert.severity === 'critical' ? 'bg-red-500' : 'bg-yellow-500'}>
                      {alert.severity}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-blue-500 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{stats.users.total}</p>
                  <p className="text-sm text-muted-foreground">Total Users</p>
                  <p className="text-xs text-muted-foreground">
                    {stats.users.artists} artists, {stats.users.customers} customers
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Package className="h-8 w-8 text-green-500 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{stats.products.total}</p>
                  <p className="text-sm text-muted-foreground">Total Products</p>
                  <p className="text-xs text-muted-foreground">
                    {stats.products.pendingReview} pending review
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-green-600 mr-3" />
                <div>
                  <p className="text-2xl font-bold">${stats.revenue.monthly.toFixed(2)}</p>
                  <p className="text-sm text-muted-foreground">Monthly Revenue</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <AlertTriangle className="h-8 w-8 text-red-500 mr-3" />
                <div>
                  <p className="text-2xl font-bold">{stats.users.pendingArtists}</p>
                  <p className="text-sm text-muted-foreground">Pending Artists</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="pending">
              Pending Reviews ({(pendingReviews?.artists?.length || 0) + (pendingReviews?.products?.length || 0)})
            </TabsTrigger>
            <TabsTrigger value="flagged">
              Flagged Items ({pendingReviews?.flaggedProducts?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="orders">Recent Orders</TabsTrigger>
            <TabsTrigger value="analytics">Top Artists</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-6">
            {/* Pending Artists */}
            {pendingReviews?.artists?.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-4">Pending Artist Approvals</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {pendingReviews.artists.map((artist: any) => (
                    <Card key={artist.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-4">
                          <h4 className="font-semibold">
                            {artist.first_name} {artist.last_name}
                          </h4>
                          <Badge variant="outline">Artist</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{artist.email}</p>
                        <p className="text-sm mb-4">
                          Business: {artist.artist_profiles?.business_name || 'Not provided'}
                        </p>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => approveArtist(artist.id)}
                            className="flex-1"
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => rejectArtist(artist.id)}
                            className="flex-1"
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Pending Products */}
            {pendingReviews?.products?.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-4">Products Pending Review</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {pendingReviews.products.map((product: any) => (
                    <Card key={product.id}>
                      <CardContent className="p-4">
                        <img
                          src={product.product_images?.[0]?.image_url || '/placeholder.svg'}
                          alt={product.title}
                          className="w-full h-40 object-cover rounded-lg mb-4"
                        />
                        <h4 className="font-semibold mb-2">{product.title}</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          by {product.artist_profiles?.business_name}
                        </p>
                        <p className="text-sm font-medium mb-4">${product.price.toFixed(2)}</p>
                        {product.authenticity_score && (
                          <p className="text-sm mb-4">
                            Authenticity Score: {(product.authenticity_score * 100).toFixed(1)}%
                          </p>
                        )}
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => approveProduct(product.id)}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => rejectProduct(product.id)}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {(!pendingReviews?.artists?.length && !pendingReviews?.products?.length) && (
              <Card>
                <CardContent className="text-center py-8">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-500" />
                  <h3 className="text-lg font-semibold mb-2">All caught up!</h3>
                  <p className="text-muted-foreground">No pending reviews at the moment</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="flagged" className="space-y-4">
            {pendingReviews?.flaggedProducts?.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {pendingReviews.flaggedProducts.map((product: any) => (
                  <Card key={product.id} className="border-red-200">
                    <CardContent className="p-4">
                      <img
                        src={product.product_images?.[0]?.image_url || '/placeholder.svg'}
                        alt={product.title}
                        className="w-full h-40 object-cover rounded-lg mb-4"
                      />
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">{product.title}</h4>
                        <Badge className="bg-red-500 text-white">Flagged</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        by {product.artist_profiles?.business_name}
                      </p>
                      <p className="text-sm font-medium mb-2">${product.price.toFixed(2)}</p>
                      {product.authenticity_score && (
                        <p className="text-sm text-red-600 mb-4">
                          Authenticity Score: {(product.authenticity_score * 100).toFixed(1)}%
                        </p>
                      )}
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => approveProduct(product.id)}
                        >
                          <Shield className="h-4 w-4 mr-1" />
                          Override
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => rejectProduct(product.id, 'Failed authenticity check')}
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Remove
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <Shield className="h-12 w-12 mx-auto mb-4 text-green-500" />
                  <h3 className="text-lg font-semibold mb-2">No flagged items</h3>
                  <p className="text-muted-foreground">All products passed authenticity checks</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="orders" className="space-y-4">
            {stats.orders.recent.length > 0 ? (
              stats.orders.recent.map((order: any) => (
                <Card key={order.id}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold">Order #{order.order_number}</h4>
                        <p className="text-sm text-muted-foreground">
                          Customer: {order.user_profiles?.first_name} {order.user_profiles?.last_name}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(order.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">${order.total_amount.toFixed(2)}</p>
                        <Badge className={order.status === 'delivered' ? 'bg-green-500' : 'bg-yellow-500'}>
                          {order.status}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">No recent orders</h3>
                  <p className="text-muted-foreground">Orders will appear here when placed</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            {stats.topArtists.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {stats.topArtists.map((artist: any, index: number) => (
                  <Card key={artist.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-semibold">#{index + 1} {artist.business_name}</h4>
                        <Badge variant="outline">Top Seller</Badge>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Total Sales:</span>
                          <span className="text-sm font-medium">${artist.total_sales.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Rating:</span>
                          <span className="text-sm font-medium">{artist.rating.toFixed(1)} ⭐</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Followers:</span>
                          <span className="text-sm font-medium">{artist.follower_count}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">No artist data yet</h3>
                  <p className="text-muted-foreground">Artist performance data will appear here</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;