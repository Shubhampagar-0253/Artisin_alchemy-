import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Star, MapPin, Award, Users, ArrowRight } from "lucide-react";

const ArtistSpotlight = () => {
  const featuredArtists = [
    {
      id: "1",
      name: "Maria Santos",
      specialty: "Ceramic Artist",
      location: "Oaxaca, Mexico",
      rating: 4.9,
      followers: 1200,
      yearsExperience: 15,
      description: "Maria creates stunning pottery using traditional Zapotec techniques passed down through generations.",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      coverImage: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop",
      verified: true,
      featured: true
    },
    {
      id: "2", 
      name: "James Cooper",
      specialty: "Woodworker",
      location: "Vermont, USA",
      rating: 4.8,
      followers: 890,
      yearsExperience: 22,
      description: "Master craftsman specializing in sustainable furniture using locally sourced hardwoods.",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      coverImage: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=300&fit=crop",
      verified: true,
      featured: false
    },
    {
      id: "3",
      name: "Priya Sharma", 
      specialty: "Textile Artist",
      location: "Rajasthan, India",
      rating: 5.0,
      followers: 2100,
      yearsExperience: 18,
      description: "Priya weaves intricate tapestries using ancient block printing and natural dyeing methods.",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      coverImage: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=300&fit=crop",
      verified: true,
      featured: true
    }
  ];

  return (
    <section className="py-16 bg-gradient-warm">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12 space-y-4">
          <Badge variant="secondary" className="bg-artisan-warm text-accent font-medium">
            <Award className="h-3 w-3 mr-1" />
            Featured Creators
          </Badge>
          <h2 className="text-4xl font-bold text-foreground">
            Meet Our Talented
            <span className="block text-primary">Artisan Community</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Get to know the passionate creators behind our handcrafted treasures. 
            Each artist brings unique skills, cultural heritage, and stories to their craft.
          </p>
        </div>

        {/* Artists Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {featuredArtists.map((artist) => (
            <Card key={artist.id} className="group overflow-hidden shadow-soft hover:shadow-warm transition-smooth cursor-pointer">
              {/* Cover Image */}
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={artist.coverImage} 
                  alt={`${artist.name}'s workshop`}
                  className="w-full h-full object-cover transition-smooth group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-accent/60 to-transparent" />
                
                {/* Featured Badge */}
                {artist.featured && (
                  <Badge variant="secondary" className="absolute top-4 left-4 bg-primary text-primary-foreground">
                    Featured Artist
                  </Badge>
                )}

                {/* Artist Avatar */}
                <div className="absolute -bottom-6 left-6">
                  <div className="relative">
                    <img 
                      src={artist.avatar} 
                      alt={artist.name}
                      className="w-12 h-12 rounded-full border-4 border-card object-cover"
                    />
                    {artist.verified && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-primary rounded-full flex items-center justify-center">
                        <Award className="h-2 w-2 text-primary-foreground" />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <CardContent className="pt-8 pb-6 space-y-4">
                {/* Artist Info */}
                <div>
                  <h3 className="font-bold text-lg text-foreground group-hover:text-primary transition-smooth">
                    {artist.name}
                  </h3>
                  <p className="text-artisan-story font-medium">{artist.specialty}</p>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                    <MapPin className="h-3 w-3" />
                    {artist.location}
                  </div>
                </div>

                {/* Stats */}
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1">
                    <Star className="h-3 w-3 fill-primary text-primary" />
                    <span className="font-medium">{artist.rating}</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Users className="h-3 w-3" />
                    <span>{artist.followers} followers</span>
                  </div>
                  <div className="text-muted-foreground">
                    {artist.yearsExperience}+ years
                  </div>
                </div>

                {/* Description */}
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {artist.description}
                </p>

                {/* Action Button */}
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-smooth"
                >
                  View Profile & Works
                  <ArrowRight className="ml-2 h-3 w-3" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <Button variant="hero" size="xl" className="shadow-warm">
            Explore All Artists
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ArtistSpotlight;