import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, ShoppingCart, Heart, User, Menu } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";

const Header = () => {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  return (
    <header className="bg-card shadow-soft border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4">
        {/* Top bar with user actions */}
        <div className="flex items-center justify-between py-3 border-b border-border">
          <div className="text-sm text-muted-foreground">
            Free shipping on orders over $50 • Support local artisans
          </div>
          <div className="flex items-center gap-4">
            {!user && (
              <Button variant="ghost" size="sm" onClick={() => navigate('/auth')}>
                Sell on Artisan Alchemy
              </Button>
            )}
            {user ? (
              <div className="flex items-center gap-2">
                <span className="text-sm">
                  Welcome, {profile?.first_name || user.email}
                </span>
                <Button variant="outline" size="sm" onClick={() => navigate('/dashboard')}>
                  <User className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
                <Button variant="ghost" size="sm" onClick={signOut}>
                  Sign Out
                </Button>
              </div>
            ) : (
              <Button variant="outline" size="sm" onClick={() => navigate('/auth')}>
                <User className="h-4 w-4 mr-2" />
                Sign In
              </Button>
            )}
          </div>
        </div>

        {/* Main header */}
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <div className="flex items-center">
            <h1 className="text-2xl font-bold bg-gradient-hero bg-clip-text text-transparent">
              Artisan Alchemy
            </h1>
          </div>

          {/* Search bar */}
          <div className="flex-1 max-w-2xl mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input 
                placeholder="Search for handcrafted treasures..." 
                className="pl-10 pr-4 py-2 rounded-lg border-border focus:ring-primary"
              />
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" className="relative">
              <Heart className="h-5 w-5" />
              <Badge variant="secondary" className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center text-xs">
                3
              </Badge>
            </Button>
            <Button variant="ghost" size="sm" className="relative">
              <ShoppingCart className="h-5 w-5" />
              <Badge variant="secondary" className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center text-xs">
                2
              </Badge>
            </Button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex items-center justify-between py-3">
          <div className="flex items-center gap-8">
            <Button variant="ghost">All Categories</Button>
            <Button variant="ghost">Pottery & Ceramics</Button>
            <Button variant="ghost">Textiles & Fiber</Button>
            <Button variant="ghost">Wood & Furniture</Button>
            <Button variant="ghost">Jewelry & Accessories</Button>
            <Button variant="ghost">Art & Paintings</Button>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm">Best Sellers</Button>
            <Button variant="ghost" size="sm">New Arrivals</Button>
            <Button variant="ghost" size="sm">Featured Artists</Button>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;