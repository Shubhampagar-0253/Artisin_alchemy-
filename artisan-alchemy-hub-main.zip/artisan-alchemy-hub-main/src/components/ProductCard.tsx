import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, ShoppingCart, Star, Eye } from "lucide-react";
import { useState } from "react";

interface ProductCardProps {
  id: string;
  title: string;
  artist: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  reviewCount: number;
  isHandcrafted?: boolean;
  isFeatured?: boolean;
  category: string;
}

const ProductCard = ({ 
  title, 
  artist, 
  price, 
  originalPrice,
  image, 
  rating, 
  reviewCount,
  isHandcrafted = true,
  isFeatured = false,
  category 
}: ProductCardProps) => {
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  return (
    <Card 
      className="group relative overflow-hidden shadow-soft hover:shadow-warm transition-smooth cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image Container */}
      <div className="relative aspect-square overflow-hidden">
        <img 
          src={image} 
          alt={title}
          className="w-full h-full object-cover transition-smooth group-hover:scale-105"
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {isFeatured && (
            <Badge variant="secondary" className="bg-primary text-primary-foreground text-xs">
              Featured
            </Badge>
          )}
          {isHandcrafted && (
            <Badge variant="outline" className="bg-artisan-warm text-accent text-xs border-artisan-craft">
              Handcrafted
            </Badge>
          )}
        </div>

        {/* Wishlist Button */}
        <Button
          variant="ghost"
          size="icon"
          className={`absolute top-3 right-3 bg-card/80 backdrop-blur-sm hover:bg-card transition-smooth ${
            isWishlisted ? 'text-red-500' : 'text-muted-foreground'
          }`}
          onClick={(e) => {
            e.stopPropagation();
            setIsWishlisted(!isWishlisted);
          }}
        >
          <Heart className={`h-4 w-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </Button>

        {/* Quick Actions Overlay */}
        <div className={`absolute inset-0 bg-accent/60 flex items-center justify-center gap-2 transition-smooth ${
          isHovered ? 'opacity-100' : 'opacity-0'
        }`}>
          <Button variant="secondary" size="sm">
            <Eye className="h-4 w-4 mr-2" />
            Quick View
          </Button>
          <Button variant="default" size="sm">
            <ShoppingCart className="h-4 w-4 mr-2" />
            Add to Cart
          </Button>
        </div>
      </div>

      <CardContent className="p-4 space-y-3">
        {/* Category */}
        <div className="text-xs text-muted-foreground uppercase tracking-wider">
          {category}
        </div>

        {/* Title */}
        <h3 className="font-semibold text-foreground line-clamp-2 group-hover:text-primary transition-smooth">
          {title}
        </h3>

        {/* Artist */}
        <p className="text-sm text-muted-foreground">
          by <span className="text-artisan-story font-medium">{artist}</span>
        </p>

        {/* Rating */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <Star className="h-3 w-3 fill-primary text-primary" />
            <span className="text-sm font-medium">{rating}</span>
          </div>
          <span className="text-xs text-muted-foreground">({reviewCount} reviews)</span>
        </div>

        {/* Price */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-primary">${price}</span>
            {originalPrice && (
              <span className="text-sm text-muted-foreground line-through">
                ${originalPrice}
              </span>
            )}
          </div>
          
          <Button 
            variant="story" 
            size="sm"
            className="opacity-0 group-hover:opacity-100 transition-smooth"
          >
            View Story
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;