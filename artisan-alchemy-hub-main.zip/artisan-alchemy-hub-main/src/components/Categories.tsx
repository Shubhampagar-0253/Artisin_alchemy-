import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Palette, Scissors, Hammer, Gem, Brush, Leaf } from "lucide-react";

const Categories = () => {
  const categories = [
    {
      id: "pottery",
      name: "Pottery & Ceramics",
      description: "Handcrafted bowls, vases, and decorative pieces",
      icon: Palette,
      itemCount: 1200,
      color: "bg-amber-100 text-amber-700",
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=200&fit=crop",
      trending: true
    },
    {
      id: "textiles",
      name: "Textiles & Fiber",
      description: "Woven fabrics, embroidery, and tapestries",
      icon: Scissors,
      itemCount: 890,
      color: "bg-rose-100 text-rose-700",
      image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=300&h=200&fit=crop",
      trending: false
    },
    {
      id: "wood",
      name: "Wood & Furniture",
      description: "Carved sculptures, furniture, and home decor",
      icon: Hammer,
      itemCount: 650,
      color: "bg-green-100 text-green-700",
      image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=300&h=200&fit=crop",
      trending: true
    },
    {
      id: "jewelry",
      name: "Jewelry & Accessories",
      description: "Handmade jewelry, bags, and accessories",
      icon: Gem,
      itemCount: 2100,
      color: "bg-purple-100 text-purple-700",
      image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=300&h=200&fit=crop",
      trending: false
    },
    {
      id: "art",
      name: "Art & Paintings",
      description: "Original paintings, prints, and wall art",
      icon: Brush,
      itemCount: 780,
      color: "bg-blue-100 text-blue-700",
      image: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=300&h=200&fit=crop",
      trending: true
    },
    {
      id: "natural",
      name: "Natural & Organic",
      description: "Skincare, candles, and wellness products",
      icon: Leaf,
      itemCount: 420,
      color: "bg-emerald-100 text-emerald-700",
      image: "https://images.unsplash.com/photo-1556909114-f6069ca46d1d?w=300&h=200&fit=crop",
      trending: false
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12 space-y-4">
          <Badge variant="secondary" className="bg-artisan-warm text-accent font-medium">
            <Palette className="h-3 w-3 mr-1" />
            Shop by Category
          </Badge>
          <h2 className="text-4xl font-bold text-foreground">
            Explore Handcrafted
            <span className="block text-primary">Categories</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            From traditional pottery to modern textiles, discover authentic craftsmanship 
            across diverse categories, each with its own unique story and heritage.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {categories.map((category) => {
            const IconComponent = category.icon;
            return (
              <Card 
                key={category.id} 
                className="group overflow-hidden shadow-soft hover:shadow-warm transition-smooth cursor-pointer border-0 bg-card"
              >
                {/* Category Image */}
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={category.image} 
                    alt={category.name}
                    className="w-full h-full object-cover transition-smooth group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-accent/80 via-accent/20 to-transparent" />
                  
                  {/* Trending Badge */}
                  {category.trending && (
                    <Badge variant="secondary" className="absolute top-4 right-4 bg-primary text-primary-foreground">
                      Trending
                    </Badge>
                  )}

                  {/* Category Icon */}
                  <div className="absolute bottom-4 left-4">
                    <div className={`w-12 h-12 rounded-full ${category.color} flex items-center justify-center shadow-soft`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                  </div>

                  {/* Item Count */}
                  <div className="absolute bottom-4 right-4 bg-card/90 backdrop-blur-sm rounded-lg px-3 py-1">
                    <span className="text-sm font-medium text-foreground">{category.itemCount} items</span>
                  </div>
                </div>

                <CardContent className="p-6 space-y-3">
                  <div>
                    <h3 className="font-bold text-lg text-foreground group-hover:text-primary transition-smooth">
                      {category.name}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {category.description}
                    </p>
                  </div>

                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="w-full justify-between group-hover:bg-primary/5 group-hover:text-primary transition-smooth"
                  >
                    Browse Category
                    <ArrowRight className="h-4 w-4 transition-smooth group-hover:translate-x-1" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center space-y-4">
          <p className="text-muted-foreground">
            Can't find what you're looking for? Browse our complete collection
          </p>
          <Button variant="outline" size="lg">
            View All Categories
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Categories;