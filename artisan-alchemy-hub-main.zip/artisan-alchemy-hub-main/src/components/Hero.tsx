import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Sparkles, Heart, Star } from "lucide-react";
import heroImage from "@/assets/hero-artisan.jpg";

const Hero = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-warm">
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <Badge variant="secondary" className="bg-artisan-warm text-accent font-medium">
                <Sparkles className="h-3 w-3 mr-1" />
                Handcrafted with Love
              </Badge>
              
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                Discover Authentic
                <span className="block bg-gradient-hero bg-clip-text text-transparent">
                  Artisan Treasures
                </span>
              </h1>
              
              <p className="text-xl text-muted-foreground leading-relaxed max-w-lg">
                Every piece tells a story. Connect with talented artisans and discover 
                one-of-a-kind handcrafted items that celebrate creativity and craftsmanship.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-warm font-semibold">
                Explore Collections
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/5">
                Meet Our Artists
              </Button>
            </div>

            {/* Stats */}
            <div className="flex items-center gap-8 pt-8 border-t border-border">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">500+</div>
                <div className="text-sm text-muted-foreground">Verified Artists</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">10k+</div>
                <div className="text-sm text-muted-foreground">Unique Items</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1">
                  <Star className="h-4 w-4 fill-primary text-primary" />
                  <span className="text-2xl font-bold text-primary">4.9</span>
                </div>
                <div className="text-sm text-muted-foreground">Customer Rating</div>
              </div>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-story">
              <img 
                src={heroImage} 
                alt="Artisan workspace with handcrafted items"
                className="w-full h-[600px] object-cover"
              />
              
              {/* Floating cards */}
              <div className="absolute top-6 left-6 bg-card/95 backdrop-blur-sm rounded-lg p-4 shadow-soft">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-craft rounded-full flex items-center justify-center">
                    <Heart className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="font-semibold text-sm">Featured Today</div>
                    <div className="text-xs text-muted-foreground">Ceramic Collection</div>
                  </div>
                </div>
              </div>

              <div className="absolute bottom-6 right-6 bg-card/95 backdrop-blur-sm rounded-lg p-4 shadow-soft">
                <div className="text-right">
                  <div className="text-2xl font-bold text-primary">$49</div>
                  <div className="text-xs text-muted-foreground">Starting from</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;