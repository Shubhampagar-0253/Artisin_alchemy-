import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import CustomerDashboard from '@/components/dashboard/CustomerDashboard';
import ArtistDashboard from '@/components/dashboard/ArtistDashboard';
import AdminDashboard from '@/components/dashboard/AdminDashboard';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const { profile, loading } = useAuth();
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <CardTitle>Profile Not Found</CardTitle>
            <CardDescription>
              We couldn't find your profile. Please try signing in again.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate('/auth')} className="w-full">
              Go to Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Render different dashboards based on user role
  switch (profile.role) {
    case 'admin':
      return <AdminDashboard />;
    case 'artist':
      return <ArtistDashboard profile={profile} />;
    case 'customer':
    default:
      return <CustomerDashboard profile={profile} />;
  }
};

export default Dashboard;