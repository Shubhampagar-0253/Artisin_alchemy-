import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";

interface StoryRequest {
  productId: string;
  productTitle: string;
  productDescription: string;
  materials: string[];
  artistName: string;
  category: string;
  customKeywords?: string[];
  culturalBackground?: string;
  inspirationSource?: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        global: {
          headers: { Authorization: req.headers.get("Authorization")! },
        },
      }
    );

    // Verify user is authenticated and is an artist
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      throw new Error("Authentication required");
    }

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (profile?.role !== 'artist') {
      throw new Error("Only artists can generate stories");
    }

    const {
      productId,
      productTitle,
      productDescription,
      materials,
      artistName,
      category,
      customKeywords,
      culturalBackground,
      inspirationSource
    }: StoryRequest = await req.json();

    // Verify artist owns this product
    const { data: product } = await supabase
      .from('products')
      .select('artist_id')
      .eq('id', productId)
      .single();

    if (product?.artist_id !== user.id) {
      throw new Error("You can only generate stories for your own products");
    }

    // Prepare prompt for AI story generation
    const materialsText = materials.join(', ');
    const keywordsText = customKeywords ? customKeywords.join(', ') : '';
    
    const prompt = `Create an engaging, emotional story about a handcrafted ${category.toLowerCase()} piece titled "${productTitle}".

Product Details:
- Created by: ${artistName}
- Materials: ${materialsText}
- Description: ${productDescription}
${culturalBackground ? `- Cultural Background: ${culturalBackground}` : ''}
${inspirationSource ? `- Inspiration: ${inspirationSource}` : ''}
${keywordsText ? `- Keywords to include: ${keywordsText}` : ''}

Write a compelling story (200-400 words) that includes:
1. The inspiration behind this piece
2. The creation process and techniques used
3. The emotional connection and meaning
4. Why this piece is special and unique
5. The cultural or traditional significance (if applicable)

Make it personal, authentic, and emotionally engaging to help customers connect with the artisan's journey and craftsmanship. Write in first person as the artist.`;

    // Call OpenAI API
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are a talented writer specializing in crafting authentic, emotional stories about handmade artisan products. Your stories help customers connect with the heart and soul behind each creation.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 600,
        temperature: 0.8,
      }),
    });

    if (!openaiResponse.ok) {
      throw new Error('Failed to generate story with AI');
    }

    const openaiData = await openaiResponse.json();
    const generatedStory = openaiData.choices[0].message.content;

    // Parse the story into structured sections
    const storyLines = generatedStory.split('\n').filter((line: string) => line.trim());
    
    // Try to extract different sections
    let inspiration = '';
    let creationProcess = '';
    let culturalSignificance = '';
    let fullStory = generatedStory;

    // Simple parsing - in production, you might want more sophisticated parsing
    storyLines.forEach((line: string, index: number) => {
      if (line.toLowerCase().includes('inspiration') && !inspiration) {
        inspiration = storyLines.slice(index, index + 2).join(' ');
      }
      if (line.toLowerCase().includes('process') || line.toLowerCase().includes('technique')) {
        creationProcess = storyLines.slice(index, index + 2).join(' ');
      }
      if (line.toLowerCase().includes('cultural') || line.toLowerCase().includes('traditional')) {
        culturalSignificance = storyLines.slice(index, index + 2).join(' ');
      }
    });

    // Save the generated story
    const { data: storyData, error: storyError } = await supabase
      .from('product_stories')
      .upsert({
        product_id: productId,
        story_text: fullStory,
        story_type: 'ai_generated',
        inspiration: inspiration || inspirationSource || 'A unique creative vision',
        creation_process: creationProcess || 'Carefully handcrafted with traditional techniques',
        cultural_significance: culturalSignificance || culturalBackground || '',
        generated_keywords: customKeywords || [],
        is_published: false // Artist can review before publishing
      })
      .select()
      .single();

    if (storyError) {
      throw new Error(`Failed to save story: ${storyError.message}`);
    }

    // Log the AI usage
    await supabase.from('security_logs').insert({
      user_id: user.id,
      event_type: 'ai_story_generated',
      severity: 'low',
      description: 'AI story generated for product',
      metadata: { 
        product_id: productId, 
        story_id: storyData.id,
        word_count: fullStory.split(' ').length
      }
    });

    return new Response(
      JSON.stringify({
        success: true,
        story: storyData,
        message: 'Story generated successfully! Review and publish when ready.'
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error('Story generation error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  }
});