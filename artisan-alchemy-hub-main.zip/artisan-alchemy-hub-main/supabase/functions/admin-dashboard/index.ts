import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";

interface AdminAction {
  action: 'approve_artist' | 'reject_artist' | 'suspend_artist' | 'approve_product' | 'reject_product' | 'get_stats' | 'get_pending_reviews';
  userId?: string;
  productId?: string;
  reason?: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Verify admin authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Authorization header required");
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace("Bearer ", "")
    );
    
    if (authError || !user) {
      throw new Error("Authentication required");
    }

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (profile?.role !== 'admin') {
      throw new Error("Admin access required");
    }

    const { action, userId, productId, reason }: AdminAction = await req.json();

    switch (action) {
      case 'get_stats':
        // Get comprehensive dashboard statistics
        const [
          { count: totalUsers },
          { count: totalArtists },
          { count: pendingArtists },
          { count: totalProducts },
          { count: pendingProducts },
          { count: totalOrders },
          { data: recentOrders },
          { data: topArtists },
          { data: securityAlerts }
        ] = await Promise.all([
          supabase.from('user_profiles').select('*', { count: 'exact', head: true }),
          supabase.from('user_profiles').select('*', { count: 'exact', head: true }).eq('role', 'artist'),
          supabase.from('user_profiles').select('*', { count: 'exact', head: true }).eq('role', 'artist').eq('verification_status', 'pending'),
          supabase.from('products').select('*', { count: 'exact', head: true }),
          supabase.from('products').select('*', { count: 'exact', head: true }).eq('authenticity_status', 'pending_review'),
          supabase.from('orders').select('*', { count: 'exact', head: true }),
          supabase.from('orders').select(`
            id, order_number, total_amount, status, created_at,
            user_profiles (first_name, last_name, email)
          `).order('created_at', { ascending: false }).limit(10),
          supabase.from('artist_profiles').select(`
            id, business_name, rating, total_sales, follower_count,
            user_profiles (first_name, last_name)
          `).order('total_sales', { ascending: false }).limit(10),
          supabase.from('security_logs').select('*')
            .in('severity', ['high', 'critical'])
            .eq('resolved', false)
            .order('created_at', { ascending: false })
            .limit(20)
        ]);

        // Calculate revenue (simplified)
        const { data: revenueData } = await supabase
          .from('orders')
          .select('total_amount, created_at')
          .eq('payment_status', 'completed')
          .gte('created_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString());

        const monthlyRevenue = revenueData?.reduce((sum, order) => sum + parseFloat(order.total_amount), 0) || 0;

        return new Response(
          JSON.stringify({
            success: true,
            stats: {
              users: {
                total: totalUsers,
                artists: totalArtists,
                pendingArtists: pendingArtists,
                customers: totalUsers - totalArtists
              },
              products: {
                total: totalProducts,
                pendingReview: pendingProducts
              },
              orders: {
                total: totalOrders,
                recent: recentOrders
              },
              revenue: {
                monthly: monthlyRevenue,
                currency: 'USD'
              },
              topArtists,
              securityAlerts
            }
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );

      case 'get_pending_reviews':
        // Get items pending admin review
        const [
          { data: pendingArtistsList },
          { data: pendingProductsList },
          { data: flaggedProducts }
        ] = await Promise.all([
          supabase.from('user_profiles').select(`
            id, first_name, last_name, email, created_at,
            artist_profiles (business_name, bio, specialties, location)
          `).eq('role', 'artist').eq('verification_status', 'pending'),
          
          supabase.from('products').select(`
            id, title, price, created_at, authenticity_score,
            artist_profiles (business_name),
            product_images (image_url)
          `).eq('authenticity_status', 'pending_review'),
          
          supabase.from('products').select(`
            id, title, price, authenticity_score, created_at,
            artist_profiles (business_name),
            product_images (image_url)
          `).eq('authenticity_status', 'suspicious')
        ]);

        return new Response(
          JSON.stringify({
            success: true,
            pending: {
              artists: pendingArtistsList,
              products: pendingProductsList,
              flaggedProducts
            }
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );

      case 'approve_artist':
        if (!userId) throw new Error("User ID required");

        // Update user profile
        await supabase
          .from('user_profiles')
          .update({ verification_status: 'approved' })
          .eq('id', userId);

        // Update artist profile
        await supabase
          .from('artist_profiles')
          .update({
            verification_status: 'approved',
            verification_date: new Date().toISOString(),
            verified_by: user.id
          })
          .eq('id', userId);

        // Log the action
        await supabase.from('security_logs').insert({
          user_id: userId,
          event_type: 'artist_approved',
          severity: 'low',
          description: 'Artist account approved by admin',
          metadata: { approved_by: user.id }
        });

        return new Response(
          JSON.stringify({ success: true, message: 'Artist approved successfully' }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );

      case 'reject_artist':
        if (!userId) throw new Error("User ID required");

        await supabase
          .from('user_profiles')
          .update({ verification_status: 'rejected' })
          .eq('id', userId);

        await supabase.from('security_logs').insert({
          user_id: userId,
          event_type: 'artist_rejected',
          severity: 'medium',
          description: `Artist account rejected: ${reason || 'No reason provided'}`,
          metadata: { rejected_by: user.id, reason }
        });

        return new Response(
          JSON.stringify({ success: true, message: 'Artist rejected' }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );

      case 'approve_product':
        if (!productId) throw new Error("Product ID required");

        await supabase
          .from('products')
          .update({ authenticity_status: 'verified' })
          .eq('id', productId);

        await supabase.from('security_logs').insert({
          event_type: 'product_approved',
          severity: 'low',
          description: 'Product approved by admin',
          metadata: { product_id: productId, approved_by: user.id }
        });

        return new Response(
          JSON.stringify({ success: true, message: 'Product approved' }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );

      case 'reject_product':
        if (!productId) throw new Error("Product ID required");

        await supabase
          .from('products')
          .update({ 
            authenticity_status: 'suspicious',
            is_active: false 
          })
          .eq('id', productId);

        await supabase.from('security_logs').insert({
          event_type: 'product_rejected',
          severity: 'high',
          description: `Product rejected: ${reason || 'Failed authenticity check'}`,
          metadata: { product_id: productId, rejected_by: user.id, reason }
        });

        return new Response(
          JSON.stringify({ success: true, message: 'Product rejected and deactivated' }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );

      default:
        throw new Error("Invalid action");
    }

  } catch (error) {
    console.error('Admin dashboard error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  }
});