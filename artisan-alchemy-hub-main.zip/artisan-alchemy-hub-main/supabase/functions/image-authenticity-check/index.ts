import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";

interface AuthenticityRequest {
  productId: string;
  imageUrl: string;
  category: string;
}

interface AuthenticityResult {
  isAuthentic: boolean;
  confidence: number;
  reasons: string[];
  flaggedConcerns: string[];
}

// Mock AI authenticity checker - In production, integrate with real ML model
async function checkImageAuthenticity(imageUrl: string, category: string): Promise<AuthenticityResult> {
  // Simulate AI processing delay
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Mock analysis - replace with actual ML model
  const mockResults = {
    pottery: {
      isAuthentic: Math.random() > 0.2, // 80% authentic rate for pottery
      handmadeIndicators: [
        'Slight asymmetry in shape',
        'Visible tool marks',
        'Natural color variations',
        'Unique texture patterns',
        'Irregular glazing'
      ],
      factoryIndicators: [
        'Perfect symmetry',
        'Uniform color',
        'Smooth machine finish',
        'Identical to mass-produced items'
      ]
    },
    textiles: {
      isAuthentic: Math.random() > 0.15,
      handmadeIndicators: [
        'Irregular stitching patterns',
        'Natural fiber variations',
        'Hand-dyed color inconsistencies',
        'Unique weaving patterns',
        'Traditional crafting techniques'
      ],
      factoryIndicators: [
        'Machine-perfect stitching',
        'Synthetic materials',
        'Mass production patterns',
        'Industrial finishing'
      ]
    },
    jewelry: {
      isAuthentic: Math.random() > 0.25,
      handmadeIndicators: [
        'Hand-formed metal work',
        'Natural stone variations',
        'Artisan tool marks',
        'Unique design elements',
        'Traditional crafting methods'
      ],
      factoryIndicators: [
        'Machine-cut precision',
        'Cast metal components',
        'Identical gemstone cuts',
        'Mass production indicators'
      ]
    }
  };

  const categoryData = mockResults[category.toLowerCase() as keyof typeof mockResults] || mockResults.pottery;
  const isAuthentic = categoryData.isAuthentic;
  const confidence = Math.random() * 0.3 + 0.7; // 70-100% confidence
  
  const reasons = isAuthentic 
    ? categoryData.handmadeIndicators.slice(0, Math.floor(Math.random() * 3) + 2)
    : categoryData.factoryIndicators.slice(0, Math.floor(Math.random() * 2) + 1);
    
  const flaggedConcerns = isAuthentic 
    ? [] 
    : ['Possible mass production', 'Machine-made characteristics detected'];

  return {
    isAuthentic,
    confidence: Math.round(confidence * 10000) / 10000,
    reasons,
    flaggedConcerns
  };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        global: {
          headers: { Authorization: req.headers.get("Authorization")! },
        },
      }
    );

    // Verify user is authenticated and is an artist
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      throw new Error("Authentication required");
    }

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (profile?.role !== 'artist') {
      throw new Error("Only artists can check product authenticity");
    }

    const { productId, imageUrl, category }: AuthenticityRequest = await req.json();

    // Verify artist owns this product
    const { data: product } = await supabase
      .from('products')
      .select('artist_id, title')
      .eq('id', productId)
      .single();

    if (product?.artist_id !== user.id) {
      throw new Error("You can only check authenticity for your own products");
    }

    console.log(`Starting authenticity check for product: ${product.title}`);

    // Perform AI authenticity analysis
    const authenticityResult = await checkImageAuthenticity(imageUrl, category);

    // Determine authenticity status
    let authenticityStatus: 'verified' | 'suspicious' | 'pending_review';
    
    if (authenticityResult.isAuthentic && authenticityResult.confidence > 0.85) {
      authenticityStatus = 'verified';
    } else if (!authenticityResult.isAuthentic || authenticityResult.confidence < 0.6) {
      authenticityStatus = 'suspicious';
    } else {
      authenticityStatus = 'pending_review';
    }

    // Update product with authenticity results
    const { error: updateError } = await supabase
      .from('products')
      .update({
        authenticity_status: authenticityStatus,
        authenticity_score: authenticityResult.confidence
      })
      .eq('id', productId);

    if (updateError) {
      throw new Error(`Failed to update product authenticity: ${updateError.message}`);
    }

    // Log the authenticity check
    await supabase.from('security_logs').insert({
      user_id: user.id,
      event_type: authenticityStatus === 'suspicious' ? 'suspicious_product_detected' : 'product_authenticity_verified',
      severity: authenticityStatus === 'suspicious' ? 'high' : 'low',
      description: `Product authenticity check completed: ${authenticityStatus}`,
      metadata: {
        product_id: productId,
        confidence: authenticityResult.confidence,
        status: authenticityStatus,
        reasons: authenticityResult.reasons,
        concerns: authenticityResult.flaggedConcerns
      }
    });

    // If suspicious, notify admins
    if (authenticityStatus === 'suspicious') {
      // In production, you might want to send email notifications to admins
      console.log(`ALERT: Suspicious product detected - Product ID: ${productId}, Confidence: ${authenticityResult.confidence}`);
    }

    return new Response(
      JSON.stringify({
        success: true,
        result: {
          status: authenticityStatus,
          confidence: authenticityResult.confidence,
          isAuthentic: authenticityResult.isAuthentic,
          reasons: authenticityResult.reasons,
          concerns: authenticityResult.flaggedConcerns,
          message: authenticityStatus === 'verified' 
            ? 'Great! Your product shows clear signs of authentic handcrafting.' 
            : authenticityStatus === 'suspicious'
            ? 'This product has been flagged for review. An admin will check it soon.'
            : 'Your product is under review. We\'ll notify you once verification is complete.'
        }
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error('Authenticity check error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  }
});