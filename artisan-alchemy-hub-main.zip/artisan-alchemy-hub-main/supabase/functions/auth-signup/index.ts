import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { corsHeaders } from "../_shared/cors.ts";

interface SignupRequest {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  role: 'customer' | 'artist';
  phone?: string;
  businessName?: string;
  specialties?: string[];
  location?: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const { 
      email, 
      password, 
      firstName, 
      lastName, 
      role, 
      phone,
      businessName,
      specialties,
      location 
    }: SignupRequest = await req.json();

    // Create auth user
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });

    if (authError) {
      throw new Error(authError.message);
    }

    const userId = authData.user.id;

    // Create user profile
    const { error: profileError } = await supabase
      .from('user_profiles')
      .insert({
        id: userId,
        role,
        first_name: firstName,
        last_name: lastName,
        phone,
        verification_status: role === 'artist' ? 'pending' : 'approved'
      });

    if (profileError) {
      throw new Error(`Profile creation failed: ${profileError.message}`);
    }

    // If artist, create artist profile
    if (role === 'artist') {
      const { error: artistError } = await supabase
        .from('artist_profiles')
        .insert({
          id: userId,
          business_name: businessName || `${firstName}'s Artisan Studio`,
          bio: 'Passionate artisan creating beautiful handcrafted pieces.',
          specialties: specialties || [],
          location: location || '',
          verification_status: 'pending'
        });

      if (artistError) {
        throw new Error(`Artist profile creation failed: ${artistError.message}`);
      }
    }

    // Log successful signup
    await supabase.from('security_logs').insert({
      user_id: userId,
      event_type: 'user_signup',
      severity: 'low',
      description: `New ${role} user registered`,
      metadata: { email, role },
      ip_address: req.headers.get('x-forwarded-for'),
      user_agent: req.headers.get('user-agent')
    });

    return new Response(
      JSON.stringify({ 
        success: true, 
        userId,
        message: role === 'artist' 
          ? 'Artist account created! Please wait for verification.' 
          : 'Account created successfully!'
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error('Signup error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      }
    );
  }
});