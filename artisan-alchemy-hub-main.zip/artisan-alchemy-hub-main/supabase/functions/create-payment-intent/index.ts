import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { corsHeaders } from "../_shared/cors.ts";

interface PaymentRequest {
  cartItems: Array<{
    productId: string;
    quantity: number;
    price: number;
  }>;
  shippingAddress: {
    line1: string;
    line2?: string;
    city: string;
    state: string;
    postal_code: string;
    country: string;
  };
  billingAddress?: typeof shippingAddress;
  couponCode?: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        global: {
          headers: { Authorization: req.headers.get("Authorization")! },
        },
      }
    );

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2023-10-16",
    });

    // Verify user authentication
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      throw new Error("Authentication required");
    }

    const { cartItems, shippingAddress, billingAddress, couponCode }: PaymentRequest = await req.json();

    // Validate cart items and calculate totals
    let subtotal = 0;
    const orderItems = [];

    for (const item of cartItems) {
      const { data: product } = await supabase
        .from('products')
        .select(`
          id, title, price, stock_quantity, artist_id,
          artist_profiles (business_name)
        `)
        .eq('id', item.productId)
        .eq('is_active', true)
        .single();

      if (!product) {
        throw new Error(`Product ${item.productId} not found or inactive`);
      }

      if (product.stock_quantity < item.quantity) {
        throw new Error(`Insufficient stock for ${product.title}`);
      }

      const itemTotal = product.price * item.quantity;
      subtotal += itemTotal;

      orderItems.push({
        product_id: item.productId,
        artist_id: product.artist_id,
        quantity: item.quantity,
        unit_price: product.price,
        total_price: itemTotal,
        product_snapshot: {
          title: product.title,
          price: product.price,
          artist_name: product.artist_profiles?.business_name
        }
      });
    }

    // Apply coupon if provided
    let discountAmount = 0;
    let couponId = null;

    if (couponCode) {
      const { data: coupon } = await supabase
        .from('coupons')
        .select('*')
        .eq('code', couponCode.toUpperCase())
        .eq('is_active', true)
        .single();

      if (coupon) {
        const now = new Date();
        const validFrom = new Date(coupon.valid_from);
        const validUntil = new Date(coupon.valid_until);

        if (now >= validFrom && now <= validUntil) {
          if (!coupon.usage_limit || coupon.used_count < coupon.usage_limit) {
            if (subtotal >= (coupon.minimum_order_amount || 0)) {
              if (coupon.discount_type === 'percentage') {
                discountAmount = (subtotal * coupon.discount_value) / 100;
              } else {
                discountAmount = coupon.discount_value;
              }

              if (coupon.maximum_discount_amount) {
                discountAmount = Math.min(discountAmount, coupon.maximum_discount_amount);
              }

              couponId = coupon.id;
            } else {
              throw new Error(`Minimum order amount is $${coupon.minimum_order_amount}`);
            }
          } else {
            throw new Error("Coupon usage limit exceeded");
          }
        } else {
          throw new Error("Coupon is expired or not yet valid");
        }
      } else {
        throw new Error("Invalid coupon code");
      }
    }

    // Calculate shipping (simple flat rate - can be enhanced)
    const shippingAmount = subtotal >= 75 ? 0 : 15; // Free shipping over $75
    
    // Calculate tax (simplified - use actual tax service in production)
    const taxRate = 0.08; // 8% tax rate
    const taxAmount = (subtotal - discountAmount) * taxRate;

    const totalAmount = subtotal + shippingAmount + taxAmount - discountAmount;

    // Create order in database
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        customer_id: user.id,
        subtotal,
        tax_amount: taxAmount,
        shipping_amount: shippingAmount,
        discount_amount: discountAmount,
        total_amount: totalAmount,
        currency: 'USD',
        shipping_address: shippingAddress,
        billing_address: billingAddress || shippingAddress,
        status: 'pending',
        payment_status: 'pending'
      })
      .select()
      .single();

    if (orderError) {
      throw new Error(`Failed to create order: ${orderError.message}`);
    }

    // Create order items
    const { error: itemsError } = await supabase
      .from('order_items')
      .insert(
        orderItems.map(item => ({
          ...item,
          order_id: order.id
        }))
      );

    if (itemsError) {
      throw new Error(`Failed to create order items: ${itemsError.message}`);
    }

    // Create Stripe payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(totalAmount * 100), // Stripe uses cents
      currency: 'usd',
      metadata: {
        order_id: order.id,
        customer_id: user.id,
        coupon_code: couponCode || ''
      },
      shipping: {
        address: {
          line1: shippingAddress.line1,
          line2: shippingAddress.line2,
          city: shippingAddress.city,
          state: shippingAddress.state,
          postal_code: shippingAddress.postal_code,
          country: shippingAddress.country,
        },
        name: `${user.user_metadata?.firstName || ''} ${user.user_metadata?.lastName || ''}`.trim() || user.email,
      },
    });

    // Update order with payment intent ID
    await supabase
      .from('orders')
      .update({ payment_intent_id: paymentIntent.id })
      .eq('id', order.id);

    // Record coupon usage if applicable
    if (couponId) {
      await supabase.from('coupon_usage').insert({
        coupon_id: couponId,
        user_id: user.id,
        order_id: order.id,
        discount_amount: discountAmount
      });

      // Update coupon usage count
      await supabase
        .from('coupons')
        .update({ used_count: supabase.rpc('increment', { x: 1 }) })
        .eq('id', couponId);
    }

    // Clear user's cart after successful order creation
    await supabase
      .from('cart_items')
      .delete()
      .eq('user_id', user.id);

    return new Response(
      JSON.stringify({
        success: true,
        clientSecret: paymentIntent.client_secret,
        orderId: order.id,
        orderNumber: order.order_number,
        totalAmount,
        discountAmount,
        message: 'Order created successfully!'
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error('Payment intent creation error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  }
});